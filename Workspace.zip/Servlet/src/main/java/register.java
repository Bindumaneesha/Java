import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/register")
public class register extends GenericServlet
{
                      
	private static final String Connection = null;
	public void init()
	{
		System.out.println("init");
	}
	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		PrintWriter pw = res.getWriter();
		res.setContentType("text/html");
		String a = req.getParameter("t1");
		String b = req.getParameter("t2");
		String c = req.getParameter("t3");
		String d = req.getParameter("b1");
		/*pw.println("the employee id is " +a);
		pw.println("<br>");
		pw.println("the employee name is " +b);
		pw.println("<br>");
		pw.println("the employee address is " +c);*/
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/mphasis","root","Password@12");
			if(d.equals("insert"))
			{
			PreparedStatement ps = con.prepareStatement("insert into employee values(?,?,?)"); 
			ps.setString(1, a);
			ps.setString(2, b);
			ps.setString(3, c);
			ps.executeUpdate();
			pw.println("row inserted");
			}
			else if(d.equals("update"))
			{
			PreparedStatement ps = con.prepareStatement("update employee set name=? , address=? where empid=?"); 
			ps.setString(1, b);
			ps.setString(2, c);
			ps.setString(3, a);
			ps.executeUpdate();
			pw.println("row updated");
			}
			else if(d.equals("delete"))
			{
			PreparedStatement ps = con.prepareStatement("delete from employee where empid=?"); 
			ps.setString(1, a);
			ps.executeUpdate();
			pw.println("row deleted");
			}
			else if(d.equals("search"))
			{
				pw.println("<table border=1>");
				pw.println("<tr><td>Employee id<td>Name<td>Address<tr>");
				PreparedStatement ps = con.prepareStatement("select * from employee"); 
				ResultSet rs = ps.executeQuery();
				while(rs.next()) 
				{
					pw.println("<tr><td>"+rs.getString(1)+"<td>"+rs.getString(2)+"<td>"+rs.getString(3)+"</tr>");
				}
				pw.println("</table>");
			}
			else 
			{
				pw.println("<table border=1>");
				pw.println("<tr><td>Employee id<td>Name<td>Address<tr>");
				PreparedStatement ps = con.prepareStatement("select * from employee where empid=?");
				ps.setString(1, a);
				ResultSet rs = ps.executeQuery();
				while(rs.next()) 
				{
					pw.println("<tr><td>"+rs.getString(1)+"<td>"+rs.getString(2)+"<td>"+rs.getString(3)+"</tr>");
				}
				pw.println("</table>");
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
	public void destroy()
	{
		System.out.println("deleted");
	}
	
}



