package com.mphasis.dao;

import org.hibernate.HibernateException;

import org.hibernate.Session;
import com.mphasis.domain.Product;


import com.mphasis.dbutil.HibernateUtil;
import com.mphasis.dbutil.KeyboardUtil;
public class DeleteProduct {

	public void deleteProduct() {

		int id = KeyboardUtil.getInt("Enter id of the person to delete: ");

		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		try {
			Product p1 = (Product) session.get(Product.class, id);
			if (p1 == null) {
				System.out.println("No record to delete!");
			} else {
				session.delete(p1);
				session.getTransaction().commit();
				System.out.println("Data deleted successfully!");
			}
		} catch (HibernateException e) {
			System.out.println("Could not delete the data");
			System.err.println(e.getMessage());
			session.getTransaction().rollback();
		}

		session.close();
	}
	
}
