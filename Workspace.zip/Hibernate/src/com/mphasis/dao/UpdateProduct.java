package com.mphasis.dao;

import org.hibernate.Session;


import com.mphasis.domain.Product; 
import com.mphasis.dbutil.HibernateUtil;
import com.mphasis.dbutil.KeyboardUtil;


public class UpdateProduct {

	public void updateProduct() {
		Session session = HibernateUtil.getSession();
		int id = KeyboardUtil.getInt("Enter id: ");
		session.beginTransaction();
		Product p1 = (Product) session.get(Product.class, id);

		if (p1 == null) {
			System.out.println("No data found!");
		} else {
			String input;

			input = KeyboardUtil.getString("Name : (" + p1.getName() + ") ");
			if (!input.equals("")) {
				p1.setName(input);
			}

			input = KeyboardUtil.getString("Price: (" + p1.getPrice() + ") ");
			if (!input.equals("")) {
				double price = Double.parseDouble(input);

				p1.setPrice(price);
			}

			
			session.getTransaction().commit();
			System.out.println("Data updated back to the db.");

		}

	}
	
	
}
