package com.mphasis.dao;

import java.util.Scanner;

import org.hibernate.Session;

import com.mphasis.dbutil.HibernateUtil;
import com.mphasis.domain.Product;

public class SearchProduct {
	
	public void searchProduct(){
		Session session = HibernateUtil.getSession();
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the Product id:");
		int id = Integer.parseInt(sc.nextLine());
		Product p1 = (Product) session.get(Product.class, id);

		if (p1 == null) {
			System.out.println("No data found!");
		} else {
			System.out.println("Id  = " + p1.getId() + " "
					+ p1.getName()+ " "+ p1.getPrice());		
		}
	}	
}
