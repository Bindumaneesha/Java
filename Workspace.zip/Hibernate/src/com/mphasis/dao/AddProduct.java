package com.mphasis.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;


import com.mphasis.domain.*;
import com.mphasis.*;
import com.mphasis.dbutil.HibernateUtil;
import com.mphasis.dbutil.KeyboardUtil;


public class AddProduct {

	public void AddProducts()
	{
     	int id;
		String name;
		double price;

		id = KeyboardUtil.getInt("Enter id: ");
		name = KeyboardUtil.getString("Enter name: ");
		price = KeyboardUtil.getDouble("Enter price: ");


		Product p1 = new Product(id, name, price);
		
		
		Session session = HibernateUtil.getSession();
		Transaction tx = session.beginTransaction();
		try {
			session.save(p1);
			tx.commit();
			System.out.println("Data saved to db.");
		} catch (HibernateException e) {
			tx.rollback();
			System.out.println("There was an error while trying to save data.");
			System.out.println(e.getMessage());
		}
		
		session.close();
		

	}
	
	
	
	
}
