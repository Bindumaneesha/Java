package com.mphasis.dao;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import com.mphasis.dbutil.HibernateUtil;
import com.mphasis.domain.Product;

public class ViewProducts 
{
	public void viewProducts() 
	{
	  { 
	   Session session =HibernateUtil.getSession(); 
	   List<Product> products =session.createQuery("FROM Product").list(); 
	   session.close();
	      if (products.isEmpty()) 
	      { 
	    	  System.out.println("No products available."); 
	      }
	      else 
	      { 
	    	  System.out.println("Available Products:"); 
	    	  for (Product product :products) 
	    	  { 
	    		  System.out.println("ID: " + product.getId() + ", Name: " +product.getName() + ", Price: " + product.getPrice()); 
	    	  } 
	      }
	  }
	}
}
