package com.mphasis.app;
 
import com.mphasis.dao.AddProduct;
import com.mphasis.dao.DeleteProduct;
import com.mphasis.dao.SearchProduct;
import com.mphasis.dao.UpdateProduct;
import com.mphasis.dao.ViewProducts;
import com.mphasis.domain.Product;
 
import java.util.Scanner;
 
public class ProductManagementApp {
public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        AddProduct add = new AddProduct();
        DeleteProduct del = new DeleteProduct();
        SearchProduct search = new SearchProduct();
        UpdateProduct update = new UpdateProduct();
        ViewProducts view = new ViewProducts();
        
        while (true) {
            System.out.println("\nProduct Management Options");
            System.out.println("1. View Products");
            System.out.println("2. Add Product");
            System.out.println("3. Update Product");
            System.out.println("4. Delete Product");
            System.out.println("5. Search Product");
            System.out.println("6. Exit");
            System.out.print("Enter an option: ");
            char choice = scanner.next().toUpperCase().charAt(0);
 
            switch (choice) {
                case '1':
                	view.viewProducts();
                    break;
                case '2':
                	
                    add.AddProducts();
                    //view.viewProducts();
                    break;
                case '3':
                    
                    update.updateProduct();
                   //view.viewProducts();
                    break;
                case '4':
                    
                    del.deleteProduct();
                    break;
                case '5':
                    
                    search.searchProduct();
                    break;
                case '6':
                    System.out.println("Exiting the application.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
