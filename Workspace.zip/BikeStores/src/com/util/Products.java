package com.util;

 
public class Products {
    private int productId;
    private String productName;
    private String brandName;
    private String categoryName;
    private int modelYear;
    private double listPrice;
 
    // Getters
    public int getProductId() {
        return productId;
    }
 
    public String getProductName() {
        return productName;
    }
 
    public String getBrandName() {
        return brandName;
    }
 
    public String getCategoryName() {
        return categoryName;
    }
 
    public int getModelYear() {
        return modelYear;
    }
 
    public double getListPrice() {
        return listPrice;
    }
 
    // Setters
    public void setProductId(int productId) {
        this.productId = productId;
    }
 
    public void setProductName(String productName) {
        this.productName = productName;
    }
 
    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }
 
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
 
    public void setModelYear(int modelYear) {
        this.modelYear = modelYear;
    }
 
    public void setListPrice(double listPrice) {
        this.listPrice = listPrice;
    }
 
    @Override
    public String toString() {
        return "Product ID: " + productId + ", Product Name: " + productName + ", Brand: " + brandName +
               ", Category: " + categoryName + ", Model Year: " + modelYear + ", Price: " + listPrice;
    }
}
