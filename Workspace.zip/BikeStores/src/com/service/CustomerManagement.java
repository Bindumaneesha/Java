package com.service;
 
import java.sql.*;
import java.time.Month;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import com.util.Customers;
 
import com.db.DBHandler;
 
public class CustomerManagement 
{
    private Scanner scanner = new Scanner(System.in);
 
    public void viewProducts() {
        try (Connection conn = DBHandler.getConnection()){
        	Scanner scanner = new Scanner(System.in);
        		System.out.println("Product Catalog Viewer");
                System.out.println("1. Display All Products");
                System.out.println("2. Filter by Brand"); 
                System.out.println("3. Filter by Category"); 
                System.out.println("4. Filter by Price Range");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();
                scanner.nextLine();  // Consume newline     
                if (choice == 1) { 
                    displayProducts(conn);
                } else if (choice == 2) { 
                    filterByBrand(conn, scanner);
                } else if (choice == 3) {
                    filterByCategory(conn, scanner);
                } else if (choice == 4) { 
                    filterByPriceRange(conn, scanner);
                } else {
                    System.out.println("Invalid choice.");
                }
                conn.close();
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
     
        private static void displayProducts(Connection con) {
            try { 
                String sql = "SELECT brand_id, category_id, model_year, list_price FROM products";
                Statement stm = con.createStatement();
                ResultSet rs = stm.executeQuery(sql);
                System.out.println("Brand | Category | Model Year | Price");
                while (rs.next()) {
                    System.out.println(rs.getInt("brand_id") + " | " +
                            rs.getInt("category_id") + " | " +
                            rs.getInt("model_year") + " | " + 
                            rs.getFloat("list_price"));
                }
            } catch (SQLException e) {
                System.out.println("Database Error: " + e.getMessage());
            }
        }
     
        private static void filterByBrand(Connection con, Scanner scanner) {
            try {
                System.out.print("Enter Brand ID: ");
                int brandId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                String sql = "SELECT * FROM products WHERE brand_id = ?";
                PreparedStatement pstmt = con.prepareStatement(sql);
                pstmt.setInt(1, brandId);
                ResultSet rs = pstmt.executeQuery();
                System.out.println("Filtered by Brand ID " + brandId);
                while (rs.next()) {
                    System.out.println(rs.getString("product_name") + " | " +
                            rs.getInt("model_year") + " | " +
                            rs.getFloat("list_price"));
                }
            } catch (SQLException e) {
                System.out.println("Database Error: " + e.getMessage());
            }
        }
     
        private static void filterByCategory(Connection con, Scanner scanner) {
            try {
                System.out.print("Enter Category ID: ");
                int categoryId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                String sql = "SELECT * FROM products WHERE category_id = ?";
                PreparedStatement pstmt = con.prepareStatement(sql);
                pstmt.setInt(1, categoryId);
                ResultSet rs = pstmt.executeQuery();
                System.out.println("Filtered by Category ID " + categoryId); 
                while (rs.next()) { 
                    System.out.println(rs.getString("product_name") + " | " +
                            rs.getInt("model_year") + " | " +
                            rs.getFloat("list_price"));
                }
            } catch (SQLException e) {
                System.out.println("Database Error: " + e.getMessage());
            }
        }
     
        private static void filterByPriceRange(Connection con, Scanner scanner) {
            try {
                System.out.print("Enter Min Price: ");
                float minPrice = scanner.nextFloat();
                System.out.print("Enter Max Price: ");
                float maxPrice = scanner.nextFloat();
                scanner.nextLine();  // Consume newline
                String sql = "SELECT * FROM products WHERE list_price BETWEEN ? AND ?";
                PreparedStatement pstmt = con.prepareStatement(sql);
                pstmt.setFloat(1, minPrice);
                pstmt.setFloat(2, maxPrice);
                ResultSet rs = pstmt.executeQuery();
                System.out.println("Products in Price Range: " + minPrice + " - " + maxPrice);
                while (rs.next()) {
                    System.out.println(rs.getString("product_name") + " | " +
                            rs.getInt("model_year") + " | " +
                            rs.getFloat("list_price"));
                }
            } catch (SQLException e) {
                System.out.println("Database Error: " + e.getMessage());
            }
        }
    
        
    public void manageCustomers() {
        System.out.println("1. Add Customer");
        System.out.println("2. Search Customer");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        switch (choice) {
            case 1:
                addCustomer();
                break;
            case 2:
                searchCustomer();
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
 
    private void addCustomer() {
        Customers customer = new Customers();
        System.out.print("First Name: ");
        customer.setFirstName(scanner.nextLine());
        System.out.print("Last Name: ");
        customer.setLastName(scanner.nextLine());
        System.out.print("Phone: ");
        customer.setPhone(scanner.nextLine());
        System.out.print("Email: ");
        String email = scanner.nextLine();
        if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            System.out.println("Invalid email format.");
            return;
        }
        customer.setEmail(email);
        System.out.print("Street: ");
        customer.setStreet(scanner.nextLine());
        System.out.print("City: ");
        customer.setCity(scanner.nextLine());
        System.out.print("State: ");
        customer.setState(scanner.nextLine());
        System.out.print("Zip Code: ");
        customer.setZipCode(scanner.nextLine());
 
        try (Connection conn = DBHandler.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO customers (first_name, last_name, phone, email, street, city, state, zip_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")) {
            pstmt.setString(1, customer.getFirstName());
            pstmt.setString(2, customer.getLastName());
            pstmt.setString(3, customer.getPhone());
            pstmt.setString(4, customer.getEmail());
            pstmt.setString(5, customer.getStreet());
            pstmt.setString(6, customer.getCity());
            pstmt.setString(7, customer.getState());
            pstmt.setString(8, customer.getZipCode());
            pstmt.executeUpdate();
            System.out.println("Customer added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
    private void searchCustomer() {
        System.out.print("Enter search keyword: ");
        String keyword = scanner.nextLine();
 
        try (Connection conn = DBHandler.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM customers WHERE first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR city LIKE ?")) {
            String searchKeyword = "%" + keyword + "%";
            pstmt.setString(1, searchKeyword);
            pstmt.setString(2, searchKeyword);
            pstmt.setString(3, searchKeyword);
            pstmt.setString(4, searchKeyword);
            ResultSet rs = pstmt.executeQuery();
 
            while (rs.next()) {
                Customers customer = new Customers();
                customer.setCustomerId(rs.getInt("customer_id"));
                customer.setFirstName(rs.getString("first_name"));
                customer.setLastName(rs.getString("last_name"));
                customer.setPhone(rs.getString("phone"));
                customer.setEmail(rs.getString("email"));
               customer.setStreet(rs.getString("street"));
                customer.setCity(rs.getString("city"));
                customer.setState(rs.getString("state"));
                customer.setZipCode(rs.getString("zip_code"));
                System.out.println(customer.getCustomerId()+ " "+ customer.getFirstName() +" "+ customer.getLastName()+" "+ customer.getPhone()+ " "+customer.getEmail()
                +" "+ customer.getStreet()+" "+ customer.getCity()+ " "+ customer.getState()+" "+ customer.getZipCode());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
    public void placeOrder() {
        try (Connection conn = DBHandler.getConnection()) {
            
        	conn.setAutoCommit(false);
 
            System.out.print("Enter Customer ID: ");
            int customerId = scanner.nextInt();
            System.out.print("Enter Store ID: ");
            int storeId = scanner.nextInt();
            System.out.print("Enter Staff ID: ");
            int staffId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
 
            String orderQuery = "INSERT INTO orders (customer_id, order_status, order_date, required_date, store_id, staff_id) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement orderStmt = conn.prepareStatement(orderQuery, Statement.RETURN_GENERATED_KEYS)) {
                orderStmt.setInt(1, customerId);
                orderStmt.setInt(2, 1); // Pending status
                orderStmt.setDate(3, new Date(System.currentTimeMillis()));
                orderStmt.setDate(4, new Date(System.currentTimeMillis() + 7 * 24 * 60 * 60 * 1000)); // Required date one week later
                orderStmt.setInt(5, storeId);
                orderStmt.setInt(6, staffId);
                orderStmt.executeUpdate();
 
                ResultSet generatedKeys = orderStmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int orderId = generatedKeys.getInt(1);
 
                    System.out.print("Enter Product ID: ");
                    int productId = scanner.nextInt();
                    System.out.print("Enter Quantity: ");
                    int quantity = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
 
                    String orderItemQuery = "INSERT INTO order_items (order_id, item_id, product_id, quantity, list_price, discount) VALUES (?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement orderItemStmt = conn.prepareStatement(orderItemQuery)) {
                        orderItemStmt.setInt(1, orderId);
                        orderItemStmt.setInt(2, 1); // Item ID
                        orderItemStmt.setInt(3, productId);
                        orderItemStmt.setInt(4, quantity);
                        orderItemStmt.setDouble(5, getProductPrice(productId));
                        orderItemStmt.setDouble(6, 0); // No discount
                        orderItemStmt.executeUpdate();
                    }
                }
                conn.commit(); // Commit transaction
                System.out.println("Order placed successfully.");
            } catch (SQLException e) {
                conn.rollback(); // Rollback transaction on error
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
    private double getProductPrice(int productId) throws SQLException {
        String query = "SELECT list_price FROM products WHERE product_id = ?";
        try (Connection conn = DBHandler.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, productId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble("list_price");
            } else {
                throw new SQLException("Product not found.");
            }
        }
    }
 
    public void checkInventory() {
        System.out.print("Enter Store ID: ");
        int storeId = scanner.nextInt();
        System.out.print("Enter Product ID: ");
        int productId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
 
        String query = "SELECT quantity FROM stocks WHERE store_id = ? AND product_id = ?";
        try (Connection conn = DBHandler.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, storeId);
            pstmt.setInt(2, productId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                int quantity = rs.getInt("quantity");
                System.out.println("Stock available: " + quantity);
                if (quantity <= 0) {
                    System.out.println("Alert: Stock is insufficient.");
                }
            } else {
                System.out.println("Product not found in the specified store.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
    public void generateReport()
    {
        // Implementation for generating sales report
    	try (Connection conn = DBHandler.getConnection()) {
            // Total sales per store
            Map<Integer, Double> totalSalesPerStore = new HashMap<>();
            String totalSalesQuery = "SELECT store_id, SUM(list_price * quantity) AS total_sales FROM order_items " +
                                     "JOIN orders ON order_items.order_id = orders.order_id " +
                                     "GROUP BY store_id";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(totalSalesQuery)) {
                while (rs.next()) {
                    totalSalesPerStore.put(rs.getInt("store_id"), rs.getDouble("total_sales"));
                }
            }
 
            // Top 5 selling products
            List<ProductSales> productSalesList = new ArrayList<>();
            String topProductsQuery = "SELECT product_id, SUM(quantity) AS total_quantity FROM order_items " +
                                      "GROUP BY product_id ORDER BY total_quantity DESC LIMIT 5";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(topProductsQuery)) {
                while (rs.next()) {
                    productSalesList.add(new ProductSales(rs.getInt("product_id"), rs.getInt("total_quantity")));
                }
            }
 
            // Monthly sales trends
            Map<Month, Double> monthlySalesTrends = new HashMap<>();
            String monthlySalesQuery = "SELECT MONTH(order_date) AS month, SUM(list_price * quantity) AS total_sales " +
                                       "FROM order_items JOIN orders ON order_items.order_id = orders.order_id " +
                                       "GROUP BY MONTH(order_date)";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(monthlySalesQuery)) {
                while (rs.next()) {
                    monthlySalesTrends.put(Month.of(rs.getInt("month")), rs.getDouble("total_sales"));
                }
            }
 
            // Display the report
            System.out.println("Sales Report:");
            System.out.println("Total Sales per Store:");
            totalSalesPerStore.forEach((storeId, totalSales) ->
                System.out.println("Store ID: " + storeId + ", Total Sales: " + totalSales));
 
            System.out.println("\nTop 5 Selling Products:");
            productSalesList.forEach(productSales ->
                System.out.println("Product ID: " + productSales.getProductId() + ", Total Quantity Sold: " + productSales.getTotalQuantity()));
 
            System.out.println("\nMonthly Sales Trends:");
            monthlySalesTrends.forEach((month, totalSales) ->
                System.out.println("Month: " + month + ", Total Sales: " + totalSales));
 
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
 
    private class ProductSales {
        private int productId;
        private int totalQuantity;
 
        public ProductSales(int productId, int totalQuantity) {
            this.productId = productId;
            this.totalQuantity = totalQuantity;
        }
 
        public int getProductId() {
            return productId;
        }
 
        public int getTotalQuantity() {
            return totalQuantity;
        }
    }
    
}
 
 
 
