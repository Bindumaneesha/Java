package com.main;


import com.service.*;

import java.util.Scanner;

public class Sales {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CustomerManagement service = new CustomerManagement();
        while (true) {
            System.out.println("BikeStores Inventory & Sales Management System");
            System.out.println("1. View Product Catalog");
            System.out.println("2. Manage Customers");
            System.out.println("3. Place Order");
            System.out.println("4. Check Inventory");
            System.out.println("5. Generate Sales Report");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            switch (choice) {
                case 1:
                    service.viewProducts();
                    break;
                case 2:
                    service.manageCustomers();
                    break;
                case 3:
                    service.placeOrder();
                    break;
                case 4:
                    service.checkInventory();
                    break;
                case 5:
                    service.generateReport();
                    break;
                case 6:
                    System.out.println("Exiting the application.");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
          

        }

    }

}

 