import java.sql.SQLException;
 
public class registerBO {
    public String validate(User user) throws InvalidUserException, SQLException {
        if (user.getUserName() == null || user.getUserName().trim().isEmpty() ||
            user.getPassword() == null || user.getPassword().trim().isEmpty())
        {
            throw new InvalidUserException("All fields are mandatory.");
        }
        registerDAO loginDAO = new registerDAO();
        return loginDAO.save(user);
        
    }
}
 

 