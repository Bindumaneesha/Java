import java.io.IOException;
import java.sql.SQLException;
 
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
 
        try
        {
        	registerBO loginBO = new registerBO();
        	User user = new User(username , password);
            loginBO.validate(user);
                request.setAttribute("username", username);
                request.getRequestDispatcher("welcome.jsp").forward(request, response);
            } catch(InvalidUserException e) {
            	request.setAttribute("errorMessage", e.getMessage());
                request.getRequestDispatcher("error.jsp").forward(request, response);
            } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    }
}
 
 
 
 
 